package com.example.model;

import java.io.Serializable;

/**
 * Classe de modelo: comissao carteira
 * Gerada automaticamente pelo gerador de projetos ODM
 */
public class ComissaoCarteira implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private double valorTotalOriginacao;
    private double valorCarteiraCurtoPrazo;
    private double valorCarteiraLongoPrazo;
    private double valorCarteiraTotalemDia;
    private double idSafra;



    public ComissaoCarteira() {
    }
    
    public double getValorTotalOriginacao() {
        return valorTotalOriginacao;
    }
    
    public void setValorTotalOriginacao(double valorTotalOriginacao) {
        this.valorTotalOriginacao = valorTotalOriginacao;
    }
    
 
    
    public double getValorCarteiraCurtoPrazo() {
        return valorCarteiraCurtoPrazo;
    }
    
    public void setValorCarteiraCurtoPrazo(double valorCarteiraCurtoPrazo) {
        this.valorCarteiraCurtoPrazo = valorCarteiraCurtoPrazo;
    }
    
    public double getValorCarteiraLongoPrazo() {
        return valorCarteiraLongoPrazo;
    }
    
    public void setValorCarteiraLongoPrazo(double valorCarteiraLongoPrazo) {
        this.valorCarteiraLongoPrazo = valorCarteiraLongoPrazo;
    }
    

    
    @Override
    public String toString() {
        return "ComissaoCarteira [" +
                "valorTotalOriginacao=" + valorTotalOriginacao + ", " +
                
                "valorCarteiraCurtoPrazo=" + valorCarteiraCurtoPrazo + ", " +
                "valorCarteiraLongoPrazo=" + valorCarteiraLongoPrazo + ", " +
               
                 
                "]";
    }

	public double getValorCarteiraTotalemDia() {
		return valorCarteiraTotalemDia;
	}

	public void setValorCarteiraTotalemDia(double valorCarteiraTotalemDia) {
		this.valorCarteiraTotalemDia = valorCarteiraTotalemDia;
	}

	public double getIdSafra() {
		return idSafra;
	}

	public void setIdSafra(double idSafra) {
		this.idSafra = idSafra;
	}
}
