package com.example.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe de modelo: extrato comissao
 * Gerada automaticamente pelo gerador de projetos ODM
 */
public class ExtratoComissao implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private List<PoliticaAplicada> politicas = new ArrayList<>();
    private java.lang.String idEspecialista;
    private java.lang.String cidadeEspecialista;
    private int tempoRelacionamento;
    private java.lang.String idSafra;
    private double valorTotal;

    public ExtratoComissao() {
    }
    
    public void adicionarPolitica(PoliticaAplicada politica) {
        this.politicas.add(politica);
    }
    
    /**
     * Método de conveniência para adicionar política com parâmetros simples
     * Similar ao padrão adicionaRisco do ODM Workshop
     *
     * @param tipo Tipo da política (ex: "ORIGINACAO", "CARTEIRA", "BONUS")
     * @param nome Nome da política
     * @param valorBase Valor base para cálculo
     * @param percentual Percentual a ser aplicado
     */
    public void adicionarPolitica(String nome, double valorBase, double percentual) {
        PoliticaAplicada politica = new PoliticaAplicada();
        
        politica.setNomePolitica(nome);
        politica.setDescricaoPolitica("Política aplicada: " + nome);
        politica.setValorBase(valorBase);
        politica.setPercentualAplicado(percentual);
        politica.setValorCalculado(valorBase * percentual / 100);
        
        this.politicas.add(politica);
        this.valorTotal += politica.getValorCalculado();
    }

    public List<PoliticaAplicada> getPoliticas() {
        return politicas;
    }
    
    public java.lang.String getIdEspecialista() {
        return idEspecialista;
    }
    
    public void setIdEspecialista(java.lang.String idEspecialista) {
        this.idEspecialista = idEspecialista;
    }
    
    public java.lang.String getCidadeEspecialista() {
        return cidadeEspecialista;
    }
    
    public void setCidadeEspecialista(java.lang.String cidadeEspecialista) {
        this.cidadeEspecialista = cidadeEspecialista;
    }
    
    public int getTempoRelacionamento() {
        return tempoRelacionamento;
    }
    
    public void setTempoRelacionamento(int tempoRelacionamento) {
        this.tempoRelacionamento = tempoRelacionamento;
    }
    
    public java.lang.String getIdSafra() {
        return idSafra;
    }
    
    public void setIdSafra(java.lang.String idSafra) {
        this.idSafra = idSafra;
    }
    
    public double getValorTotal() {
        return valorTotal;
    }
    
    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }
    
    @Override
    public String toString() {
        return "ExtratoComissao [" +
                "idEspecialista=" + idEspecialista + ", " +
                "cidadeEspecialista=" + cidadeEspecialista + ", " +
                "tempoRelacionamento=" + tempoRelacionamento + ", " +
                "idSafra=" + idSafra + ", " +
                "valorTotal=" + valorTotal + ", " +
                "politicas=" + politicas +
                "]";
    }
}
