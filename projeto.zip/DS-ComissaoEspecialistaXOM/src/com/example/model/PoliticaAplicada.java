package com.example.model;

import java.io.Serializable;

/**
 * Classe de modelo: politica aplicada
 * Gerada automaticamente pelo gerador de projetos ODM
 */
public class PoliticaAplicada implements Serializable {
    
    private static final long serialVersionUID = 1L;
    

    private java.lang.String nomePolitica;
    private java.lang.String descricaoPolitica;
    private double valorBase;
    private double percentualAplicado;
    private double valorCalculado;

    public PoliticaAplicada() {
    }
    

    
    public java.lang.String getNomePolitica() {
        return nomePolitica;
    }
    
    public void setNomePolitica(java.lang.String nomePolitica) {
        this.nomePolitica = nomePolitica;
    }
    
    public java.lang.String getDescricaoPolitica() {
        return descricaoPolitica;
    }
    
    public void setDescricaoPolitica(java.lang.String descricaoPolitica) {
        this.descricaoPolitica = descricaoPolitica;
    }
    
    public double getValorBase() {
        return valorBase;
    }
    
    public void setValorBase(double valorBase) {
        this.valorBase = valorBase;
    }
    
    public double getPercentualAplicado() {
        return percentualAplicado;
    }
    
    public void setPercentualAplicado(double percentualAplicado) {
        this.percentualAplicado = percentualAplicado;
    }
    
    public double getValorCalculado() {
        return valorCalculado;
    }
    
    public void setValorCalculado(double valorCalculado) {
        this.valorCalculado = valorCalculado;
    }
    
    
    @Override
    public String toString() {
        return "PoliticaAplicada [" +
                
                "nomePolitica=" + nomePolitica + ", " +
                "descricaoPolitica=" + descricaoPolitica + ", " +
                "valorBase=" + valorBase + ", " +
                "percentualAplicado=" + percentualAplicado + ", " +
                "valorCalculado=" + valorCalculado +
                "]";
    }
}
