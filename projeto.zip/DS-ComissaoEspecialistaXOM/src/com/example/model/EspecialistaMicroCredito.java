package com.example.model;

import java.io.Serializable;

/**
 * Classe de modelo: especialista micro credito
 * Gerada automaticamente pelo gerador de projetos ODM
 */
public class EspecialistaMicroCredito implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private java.lang.String idEspecialista;
    private java.lang.String cidadeEspecialista;
    private int tempoRelacionamento;

    public EspecialistaMicroCredito() {
    }
    
    public java.lang.String getIdEspecialista() {
        return idEspecialista;
    }
    
    public void setIdEspecialista(java.lang.String idEspecialista) {
        this.idEspecialista = idEspecialista;
    }
    
    public java.lang.String getCidadeEspecialista() {
        return cidadeEspecialista;
    }
    
    public void setCidadeEspecialista(java.lang.String cidadeEspecialista) {
        this.cidadeEspecialista = cidadeEspecialista;
    }
    
    public int getTempoRelacionamento() {
        return tempoRelacionamento;
    }
    
    public void setTempoRelacionamento(int tempoRelacionamento) {
        this.tempoRelacionamento = tempoRelacionamento;
    }
    
    @Override
    public String toString() {
        return "EspecialistaMicroCredito [" +
                "idEspecialista=" + idEspecialista + ", " +
                "cidadeEspecialista=" + cidadeEspecialista + ", " +
                "tempoRelacionamento=" + tempoRelacionamento +
                "]";
    }

	
}
